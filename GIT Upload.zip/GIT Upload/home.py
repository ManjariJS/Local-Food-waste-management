import streamlit as st
import base64



st.title("Local Food Waste Management System")
st.image("C:/Users/vicky/OneDrive/Desktop/MiniProject/Source documents/foodmanagement.png")
st.header("Project introduction")
st.write("Food wastage is a significant issue, with many households and restaurants discarding surplus food while numerous people struggle with food insecurity. This project aims to develop a Local Food Wastage Management System, where:")
st.markdown("   🔶 Restaurants and individuals can list surplus food.")
st.markdown("   🔶NGOs or individuals in need can claim the food.")
st.markdown("   🔶SQL stores available food details and locations.")
st.markdown("   🔶A Streamlit app enables interaction, filtering, CRUD operation and visualization.")



# def get_base64_of_bin_file(bin_file):
   
#      with open(bin_file, 'rb') as f:
#          data = f.read()
#      return base64.b64encode(data).decode()

# def set_background(sourceimg):
#     bin_str = get_base64_of_bin_file(sourceimg)
#     sourceimg = f'''
#     <style>
#     .stApp {{
#     border: 2px solid black;
#     padding: 100px;
#     background-image:url("data:image/png;base64,{bin_str}");
#     background-repeat: no-repeat;
#      background-size: 3000px 1000px;
#     background-attachment: fixed;
#     background-position: center; 
#     background-color:Sacramento State green;
     
   
#     }}
#     </style>    
#     ''' 
#     st.markdown(sourceimg, unsafe_allow_html=True)
# set_background('C:/Users/vicky/OneDrive/Desktop/MiniProject/Source documents/reucewaste.webp') # Replace 'your_image.png' with the path to your image file

