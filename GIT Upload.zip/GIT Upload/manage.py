import streamlit as st
from  mysqlconn import get_connection
import datetime
import pandas as pd
from st_aggrid import AgGrid, GridOptionsBuilder
import matplotlib.pyplot as plt
import matplotlib as mp
mp.use('qt5agg') 
con=get_connection()
cursor=con.cursor()

page = st.sidebar.radio(
    "Go to", 
    ["CRUD Operations", "Food Management", "Learner Queries","Analytics"]
)

if page == "CRUD Operations":
    st.title("Select an action to perform")
    #st.write("Use the sidebar to navigate between pages.")
    action = st.selectbox("Select an option", ["Add","Update","Delete"])
    option= st.radio("Choose an option",
             ["Receiver","Provider","Food Listings","Claim"])
    if action=="Add":
        if option=="Receiver":
            with st.form(key="Receiver_Form"):
                receiver_id= st.text_input("Receiver_ID")
                name=st.text_input("Name")
                type=st.text_input("Type")
                city=st.text_input("City")
                contact=st.text_input("Contact")
                submitted = st.form_submit_button("Submit")
            if submitted:
                query="insert into receivers (receiver_id,name,type,city,contact) values (%s,%s,%s,%s,%s)"
                      
                values=(receiver_id,name,type,city,contact)
                cursor.execute(query,values)
                con.commit()
                con.close()
                st.success("Data inserted successfully")
        elif option=="Provider":
            with st.form(key="Provider_Form"):
                 provider_id=st.text_input("Provider_id")        
                 name=st.text_input("Name")
                 type=st.text_input("Type")
                 address=st.text_area("Address")
                 city=st.text_input("City")
                 contact=st.text_input("Contact")
                 submitted = st.form_submit_button("Submit")
            if submitted:
                query="insert into providers(provider_id,name,providers_type,address,city,contact)values(%s,%s,%s,%s,%s,%s)"
                values=(provider_id,name,type,address,city,contact)
                cursor.execute(query,values)
                con.commit()
                con.close()
                st.success("Data inserted successfully")
        elif option=="Food Listings":
            with st.form(key="FoodListings_Form"):
                food_id=st.text_input("Food_id")
                food_name=st.text_input("Food_Name")
                quantity=st.text_input("Quantity")
                expiry_date=st.date_input("Expiry_date")
                provider_id=st.text_input("Provider_id")
                provider_type=st.selectbox("select the Provider_type",["Grocery Store","Catering Service","Restaurant","Supermarket"])
                location=st.text_input("Location")
                food_type=st.selectbox ("select the type", ["Non-Vegetarian","Vegan","Vegetarian"])
                mealtype=st.selectbox("select the meal type",["Breakfast","Lunch","Dinner","Snacks"])
                submitted = st.form_submit_button("Submit")
            if submitted:
                query="insert into foodlistings(food_id,food_name,quantity,expiry_date,provider_id,provider_type,location,food_type,meal_type)values(%s,%s,%s,%s,%s,%s,%s,%s,%s)"
                values=(food_id,food_name,quantity,expiry_date,provider_id,provider_type,location,food_type,mealtype)
                cursor.execute(query,values)
                con.commit()
                con.close()
                st.success("Data inserted successfully")   
        elif option=="Claim":
            with st.form(key="Claim"):  
                claim_id=st.text_input("Claim_ID")
                food_id=st.text_input("Food_ID")
                receiver_id=st.text_input("Receiver_ID")
                status = st.selectbox("Select the status", ["Pending", "Completed", "Cancelled"])
                time_stamp = st.text_input("Enter date and time (YYYY-MM-DD HH:MM:SS):")

                if time_stamp:
                    try:
                        time_stamp = datetime.datetime.strptime(time_stamp, "%Y-%m-%d %H:%M:%S")
                    except ValueError as e:
                        st.error(f"Error parsing timestamp: {e}")
                        time_stamp = None
                else:
                        st.error("Timestamp is empty. Please provide a valid timestamp.")
                        time_stamp = None

                submitted = st.form_submit_button("submit")
            if submitted:
                query="insert into claims (Claim_ID,Food_ID,Receiver_ID,Status,time_stamp)values(%s,%s,%s,%s,%s)"
                values=(claim_id,food_id,receiver_id,status,time_stamp)   
                cursor.execute(query,values)
                con.commit()
                con.close()
                st.success("Data inserted successfully") 
    elif action=="Update":
        if option=="Claim":
            #with st.form(key="Claim"):
               
               query="""select f.food_id,f.food_name,f.quantity,f.Expiry_date,f.provider_type,f.food_type,f.meal_type,c.status from foodlistings f inner join claims c on f.food_id=c.food_id
                            and c.status in ("Pending") order by f.food_id"""
               cursor.execute(query)
               
               data=cursor.fetchall()
               
               df = pd.DataFrame(data, columns=["Food_ID","Name","Quantity","Expiry_date","Provider_type","Food_type","Meal_type","Status"])
               st.header("Update the Food Status")
               gb = GridOptionsBuilder.from_dataframe(df)
               gb.configure_selection('multiple', use_checkbox=True)
               grid_options = gb.build()  
               grid_response = AgGrid(
                 df,
                gridOptions=grid_options,
                update_mode='SELECTION_CHANGED',
                theme='blue',  # 'streamlit', 'light', 'dark', 'blue', 'fresh'
                height=400,
                width='100%',
                    )
               selected = grid_response['selected_rows']

               if  selected is not None:
                    st.subheader("Selected Items for Status Update:")
                    selected_df = pd.DataFrame(selected)
                    st.dataframe(selected_df)
                    statusupdate=st.selectbox("select an update",["Cancelled","Completed"])
                    # if st.button("Update"):
                    if statusupdate=="Completed":
                        if st.button("Update"):
                            for index,row in selected_df.iterrows():
                                #st.write(row["Food_ID"])
                                food_id = row["Food_ID"]
                            
                                    
                                update_query="update claims set Status='Completed' where Food_ID=%s"
                            #print("With parameters:", row[1])
                                cursor.execute(update_query,(food_id,))
                                con.commit()
                                con.close()
                            st.success("Status is updated")        
                    elif statusupdate=="Cancelled":
                        if st.button("Update"):
                            for index,row in selected_df.iterrows():
                                food_id=row["Food_ID"]
                                update_query="update claims set Status='Cancelled' where Food_ID=%s"
                                cursor.execute(update_query,(food_id,))
                                con.commit()
                                con.close()
                            st.success("Status is updated")    

    elif action=="Delete":
        if option=="Receiver":   
            query="""select receiver_id,name,type,city,contact from receivers"""
            cursor.execute(query)   
            data=cursor.fetchall()    
            df = pd.DataFrame(data, columns=["Receiver_ID","Name","Type","City","Contact"]) 
            st.header("Delete a row")
            gb = GridOptionsBuilder.from_dataframe(df)
            gb.configure_selection('multiple', use_checkbox=True)
            grid_options = gb.build()  
            grid_response = AgGrid(
            df,
            gridOptions=grid_options,
            update_mode='SELECTION_CHANGED',
            theme='blue',  # 'streamlit', 'light', 'dark', 'blue', 'fresh'
            height=400,
            width='100%',
            )

            selected = grid_response['selected_rows']  
            if  selected is not None:   
                st.subheader("Selected Items for Deletion")
                selected_df = pd.DataFrame(selected)
                st.dataframe(selected_df)  
                if st.button("Delete"):
                    for index,row in selected_df.iterrows():
                        receiver_id=row["Receiver_ID"]
                        delete_query="delete from receivers where Receiver_ID=%s"
                        cursor.execute(delete_query,(receiver_id,))
                        con.commit()
                        con.close()
                    st.success("Row is deleted")  

        if option=="Provider":   
            query="""select provider_id,name,providers_type,address,city,contact from providers"""
            cursor.execute(query)   
            data=cursor.fetchall()    
            df = pd.DataFrame(data, columns=["Provider_ID","Name","Type","Address","City","Contact"]) 
            st.header("Delete a row")
            gb = GridOptionsBuilder.from_dataframe(df)
            gb.configure_selection('multiple', use_checkbox=True)
            grid_options = gb.build()  
            grid_response = AgGrid(
            df,
            gridOptions=grid_options,
            update_mode='SELECTION_CHANGED',
            theme='blue',  # 'streamlit', 'light', 'dark', 'blue', 'fresh'
            height=400,
            width='100%',
            )

            selected = grid_response['selected_rows']  
            if  selected is not None:   
                st.subheader("Selected Items for Deletion:")
                selected_df = pd.DataFrame(selected)
                st.dataframe(selected_df)  
                if st.button("Delete"):
                    for index,row in selected_df.iterrows():
                        receiver_id=row["Provider_ID"]
                        delete_query="delete from providers where provider_id=%s"
                        cursor.execute(delete_query,(receiver_id,))
                        con.commit()
                        con.close()
                    st.success("Row is deleted") 

        if option=="Food Listings":   
            query="""select Food_ID,Food_Name,Quantity,Expiry_Date,Provider_ID,Provider_Type,Location,Food_Type,Meal_Type from foodlistings"""
            cursor.execute(query)   
            data=cursor.fetchall()    
            df = pd.DataFrame(data, columns=["Food_ID","Food_Name","Quantity","Expiry_Date","Provider_ID","Provider_Type","Location","Food_Type","Meal_Type"]) 
            st.header("Delete a row")
            gb = GridOptionsBuilder.from_dataframe(df)
            gb.configure_selection('multiple', use_checkbox=True)
            grid_options = gb.build()  
            grid_response = AgGrid(
            df,
            gridOptions=grid_options,
            update_mode='SELECTION_CHANGED',
            theme='blue',  # 'streamlit', 'light', 'dark', 'blue', 'fresh'
            height=400,
            width='100%',
            )

            selected = grid_response['selected_rows']  
            if  selected is not None:   
                st.subheader("Selected Items for Deletion:")
                selected_df = pd.DataFrame(selected)
                st.dataframe(selected_df)  
                if st.button("Delete"):
                    for index,row in selected_df.iterrows():
                        food_id=row["Food_ID"]
                        delete_query="delete from foodlistings where food_id=%s"
                        cursor.execute(delete_query,(food_id,))
                        con.commit()
                        con.close()
                    st.success("Row is deleted") 


        if option=="Claim":   
            query="""select Claim_ID,Food_ID,Receiver_ID,Status,Timestamp from claims"""
            cursor.execute(query)   
            data=cursor.fetchall()    
            df = pd.DataFrame(data, columns=["Claim_ID","Food_ID","Receiver_ID","Status","Timestamp"]) 
            st.header("Delete a row")
            gb = GridOptionsBuilder.from_dataframe(df)
            gb.configure_selection('multiple', use_checkbox=True)
            grid_options = gb.build()  
            grid_response = AgGrid(
            df,
            gridOptions=grid_options,
            update_mode='SELECTION_CHANGED',
            theme='blue',  # 'streamlit', 'light', 'dark', 'blue', 'fresh'
            height=400,
            width='100%',
            )

            selected = grid_response['selected_rows']  
            if  selected is not None:   
                st.subheader("Selected Items for Deletion:")
                selected_df = pd.DataFrame(selected)
                st.dataframe(selected_df)  
                if st.button("Delete"):
                    for index,row in selected_df.iterrows():
                        claim_id=row["Claim_ID"]
                        delete_query="delete from claims where claim_id=%s"
                        cursor.execute(delete_query,(food_id,))
                        con.commit()
                        con.close()
                    st.success("Row is deleted") 





elif page == "Food Management":
    st.header("This is the overview of the food management section.")
    dropbox=st.selectbox("Choose an option",["Count of food providers and receivers are there in each city","Type of food provider (restaurant, grocery store, etc.) contributes the most food",
                                             "Contact information of food providers in a specific city","Details of receivers have claimed the most food",
                                             "Total quantity of food available from all providers","City has the highest number of food listings","Commonly available food from food listings",
                                             "Total food claims have been made for each food item","Details of Provider thathad the highest number of successful food claims",
                                             "Percentage of food claims are completed vs. pending vs. canceled","Average quantity of food claimed per receiver",
                                             "The meal type (breakfast, lunch, dinner, snacks) that claimed the most","Total quantity of food donated by each provider"]) 
       
    if dropbox=="Count of food providers and receivers are there in each city":

        query="""select p.city,count(p.provider_id) as num_providers,count(r.receiver_id) as num_receivers

               from providers p right join receivers r on p.city=r.city group by p.city order by p.city"""
        cursor.execute(query)
        result=cursor.fetchall()
        con.close()
        df=pd.DataFrame(result,columns=["City","Providers_Count","Receiver_Count"])
        styles = [
             
             {'selector': 'th', 'props': [('background-color', 'grey')]},
             {'selector': 'td', 'props': [('padding', '10px')]}]
        html_table=df.style.set_table_styles(styles).to_html()
      
        st.markdown(html_table, unsafe_allow_html=True)
    elif dropbox=="Type of food provider (restaurant, grocery store, etc.) contributes the most food":
        query="""select count(provider_id) as contributor,providers_Type from providers group by providers_Type order by contributor desc limit 1
                 """
        cursor.execute(query)
        result=cursor.fetchall()
        con.close()
        df=pd.DataFrame(result,columns=["Contributor","Type"])
        styles = [
             
             {'selector': 'th', 'props': [('background-color', 'grey')]},
             {'selector': 'td', 'props': [('padding', '10px')]}]
        html_table=df.style.set_table_styles(styles).to_html()
        st.markdown(html_table, unsafe_allow_html=True)
    elif dropbox=="Contact information of food providers in a specific city":
        query="""select City,Contact from providers group by City,Contact
                 """
        cursor.execute(query)
        result=cursor.fetchall()
        con.close()
        df=pd.DataFrame(result,columns=["City","Contact"])
        styles = [
             
             {'selector': 'th', 'props': [('background-color', 'grey')]},
             {'selector': 'td', 'props': [('padding', '10px')]}]
        html_table=df.style.set_table_styles(styles).to_html()
        st.markdown(html_table, unsafe_allow_html=True)

    elif dropbox=="Details of receivers have claimed the most food":
        query="""select count(receiver_id)as receivers_count,Type from receivers group by Type order by receivers_count desc limit 1

                 """
        cursor.execute(query)
        result=cursor.fetchall()
        con.close()
        df=pd.DataFrame(result,columns=["Receivers_Count","Type"])
        styles = [
             
             {'selector': 'th', 'props': [('background-color', 'grey')]},
             {'selector': 'td', 'props': [('padding', '10px')]}]
        html_table=df.style.set_table_styles(styles).to_html()
        st.markdown(html_table, unsafe_allow_html=True)

    elif dropbox=="Total quantity of food available from all providers":
        query="""select count(quantity) as total_qty from foodlistings

                 """
        cursor.execute(query)
        result=cursor.fetchall()
        con.close()
        df=pd.DataFrame(result,columns=["Total_Quantity"])
        styles = [
             
             {'selector': 'th', 'props': [('background-color', 'grey')]},
             {'selector': 'td', 'props': [('padding', '10px')]}]
        html_table=df.style.set_table_styles(styles).to_html()
        st.markdown(html_table, unsafe_allow_html=True)

    elif dropbox=="City has the highest number of food listings":
        query="""select location,count(*) as food_listings from foodlistings group by location order by food_listings desc limit 1
                 """
        cursor.execute(query)
        result=cursor.fetchall()
        con.close()
        df=pd.DataFrame(result,columns=["Location","Food_Listings"])
        styles = [
             
             {'selector': 'th', 'props': [('background-color', 'grey')]},
             {'selector': 'td', 'props': [('padding', '10px')]}]
        html_table=df.style.set_table_styles(styles).to_html()
        st.markdown(html_table, unsafe_allow_html=True)

    elif dropbox=="Commonly available food from food listings":
        query="""select distinct food_type from foodlistings
        """
        cursor.execute(query)
        result=cursor.fetchall()
        con.close()
        df=pd.DataFrame(result,columns=["Food_Type"])
        styles = [
             
             {'selector': 'th', 'props': [('background-color', 'grey')]},
             {'selector': 'td', 'props': [('padding', '10px')]}]
        html_table=df.style.set_table_styles(styles).to_html()
        st.markdown(html_table, unsafe_allow_html=True)

    elif dropbox=="Total food claims have been made for each food item":
        query="""select f.food_name,count(c.claim_id) as food_claim from claims c

                inner join foodlistings f on c.food_id=f.food_id

                group by f.food_name order by food_claim desc

        """
        cursor.execute(query)
        result=cursor.fetchall()
        con.close()
        df=pd.DataFrame(result,columns=["Food_Name","Food_Claim"])
        styles = [
             
             {'selector': 'th', 'props': [('background-color', 'grey')]},
             {'selector': 'td', 'props': [('padding', '10px')]}]
        html_table=df.style.set_table_styles(styles).to_html()
        st.markdown(html_table, unsafe_allow_html=True)    

    elif dropbox=="Details of Provider thathad the highest number of successful food claims":
        query="""select f.provider_type,count(c.claim_id) as claim_count from claims c

                inner join foodlistings f on c.food_id=f.food_id where c.status='Completed'

                group by f.provider_type order by claim_count desc limit 1
                """
        cursor.execute(query)
        result=cursor.fetchall()
        con.close()
        df=pd.DataFrame(result,columns=["Provider_Type","Claim_Count"])
        styles = [
             
             {'selector': 'th', 'props': [('background-color', 'grey')]},
             {'selector': 'td', 'props': [('padding', '10px')]}]
        html_table=df.style.set_table_styles(styles).to_html()
        st.markdown(html_table, unsafe_allow_html=True)  

    elif dropbox=="Percentage of food claims are completed vs. pending vs. canceled":
        query=""" SELECT status,CAST(COUNT(*) AS REAL) * 100 / (SELECT COUNT(*) FROM claims) AS percentage FROM claims
                GROUP BY status
                """   
        cursor.execute(query)
        result=cursor.fetchall()
        con.close()
        df=pd.DataFrame(result,columns=["Status","Percentage"])
        styles = [
             
             {'selector': 'th', 'props': [('background-color', 'grey')]},
             {'selector': 'td', 'props': [('padding', '10px')]}]
        html_table=df.style.set_table_styles(styles).to_html()
        st.markdown(html_table, unsafe_allow_html=True)  
    elif dropbox=="Average quantity of food claimed per receiver":
        query="""select r.receiver_id,r.name,r.type,avg(f.Quantity) as average_qty from foodlistings f inner join claims c
                on f.food_id=c.food_id inner join receivers r on r.receiver_id=c.receiver_id group by r.type,r.receiver_id order by r.receiver_id
                """
        cursor.execute(query)
        result=cursor.fetchall()
        con.close()
        df=pd.DataFrame(result,columns=["Receiver_ID","Receiver_name","Type","Average_qty"])
        styles = [
             
             {'selector': 'th', 'props': [('background-color', 'grey')]},
             {'selector': 'td', 'props': [('padding', '10px')]}]
        html_table=df.style.set_table_styles(styles).to_html()
        st.markdown(html_table, unsafe_allow_html=True)  

    elif dropbox=="The meal type (breakfast, lunch, dinner, snacks) that claimed the most":
        query=""" select f.meal_type,count(claim_id)as most_claimed from foodlistings f
                    inner join claims c on f.food_id=c.food_id
            group by f.meal_type order by most_claimed desc limit 1
            """
        cursor.execute(query)
        result=cursor.fetchall()
        con.close()
        df=pd.DataFrame(result,columns=["Meal_Type","Most_claimed"])
        styles = [
             
             {'selector': 'th', 'props': [('background-color', 'grey')]},
             {'selector': 'td', 'props': [('padding', '10px')]}]
        html_table=df.style.set_table_styles(styles).to_html()
        st.markdown(html_table, unsafe_allow_html=True)
    elif dropbox=="Total quantity of food donated by each provider":
        query=""" SELECT p.Name, SUM(f.Quantity) AS TotalQuantityDonated,p.providers_type
                    FROM providers p
                    JOIN Foodlistings f ON p.provider_id = f.Provider_id
                    GROUP BY p.Name,p.providers_type
                    ORDER BY TotalQuantityDonated DESC
                """     
        cursor.execute(query)
        result=cursor.fetchall()
        con.close()
        df=pd.DataFrame(result,columns=["Name","Total_Quantity","Providers_type"])
        styles = [
             
             {'selector': 'th', 'props': [('background-color', 'grey')]},
             {'selector': 'td', 'props': [('padding', '10px')]}]
        html_table=df.style.set_table_styles(styles).to_html()
        st.markdown(html_table, unsafe_allow_html=True)
elif page=="Learner Queries":
    st.header("Learner Queries and Answers")
    querybox=st.selectbox("Select an query to execute",["Calculate the total quantity of food available","List providers in a specific city","List all providers who have not provided any food listings yet",
                                                       "List all food items with an expiry date within a certain range:","Find receivers of a specific type"])
    if querybox=="Calculate the total quantity of food available":
       query="""SELECT SUM(Quantity) AS TotalQuantity FROM foodlistings """  
       cursor.execute(query)
       result=cursor.fetchall()
       con.close()
       df=pd.DataFrame(result,columns=["Total_Quantity"])
       styles = [
             
             {'selector': 'th', 'props': [('background-color', 'grey')]},
             {'selector': 'td', 'props': [('padding', '10px')]}]
       html_table=df.style.set_table_styles(styles).to_html()
       st.markdown(html_table, unsafe_allow_html=True)
    elif querybox=="List providers in a specific city":
        st.markdown("Providers from the city='New Jessica':")
        query=""" select * from providers where city='New Jessica'
                """
        cursor.execute(query)
        result=cursor.fetchall()
        con.close()
        df=pd.DataFrame(result,columns=["Provider_ID","Name","Provider_type","Address","City","Contact"])
        styles = [
             
             {'selector': 'th', 'props': [('background-color', 'grey')]},
             {'selector': 'td', 'props': [('padding', '10px')]}]
        html_table=df.style.set_table_styles(styles).to_html()
        st.markdown(html_table, unsafe_allow_html=True)
    elif querybox=="List all providers who have not provided any food listings yet":
        st.markdown("Providers who have not provided any food listings yet")
        query=""" SELECT p.Name,p.providers_type
            FROM providers p
            LEFT JOIN Foodlistings f ON p.provider_id = f.Provider_id
                WHERE f.Food_ID IS NULL;
                """
        cursor.execute(query)
        result=cursor.fetchall()
        con.close()
        df=pd.DataFrame(result,columns=["Name","Provider_type"])
        styles = [
             
             {'selector': 'th', 'props': [('background-color', 'grey')]},
             {'selector': 'td', 'props': [('padding', '10px')]}]
        html_table=df.style.set_table_styles(styles).to_html()
        st.markdown(html_table, unsafe_allow_html=True)

    elif querybox=="List all food items with an expiry date within a certain range:":
        st.markdown("Food items that have expiry date between '2025-01-01' and '2025-03-31':")
        query="""
                select * from foodlistings where expiry_date between '2025-01-01' and '2025-03-31'
            """   
        cursor.execute(query)
        result=cursor.fetchall()
        con.close()
        df=pd.DataFrame(result,columns=["Food_ID","Food_Name","Quantity","Expiry_Date","Provider_ID","Provider_Type","Location","Food_Type","Meal_Type"])
        styles = [
             
             {'selector': 'th', 'props': [('background-color', 'grey')]},
             {'selector': 'td', 'props': [('padding', '10px')]}]
        html_table=df.style.set_table_styles(styles).to_html()
        st.markdown(html_table, unsafe_allow_html=True)
    elif querybox=="Find receivers of a specific type":
        st.markdown("Receivers of type Shelter")
        query="""
                select * from receivers where type='Shelter'
            """   
        cursor.execute(query)
        result=cursor.fetchall()
        con.close()
        df=pd.DataFrame(result,columns=["Receiver_ID","Name","Type","City","Contact"])
        styles = [
             
             {'selector': 'th', 'props': [('background-color', 'grey')]},
             {'selector': 'td', 'props': [('padding', '10px')]}]
        html_table=df.style.set_table_styles(styles).to_html()
        st.markdown(html_table, unsafe_allow_html=True)


elif page == "Analytics":
    st.title("Analytics")
    st.write("This section is for analytics and reporting.")
  
    analysis=st.selectbox("Choose an option",["Total Food Waste","Most claimed food items"])
    if analysis=="Total Food Waste":
        st.header("Total Food waste")
        query="select food_type,sum(Quantity) as TotalWaste from foodlistings where expiry_date<date(now()) group by food_type"
        cursor.execute(query)
        result=cursor.fetchall()
        total_waste = result
        con.close()
        labels = [row[0] for row in result]
        values = [row[1] for row in result]
        df=pd.DataFrame(result,columns=["Food_Type","Total_Waste"])
        styles = [
             
             {'selector': 'th', 'props': [('background-color', 'grey')]},
             {'selector': 'td', 'props': [('padding', '10px')]}]
        html_table=df.style.set_table_styles(styles).to_html()
        st.markdown(html_table, unsafe_allow_html=True)
        plt.title("Total Food Waste")
        fig, ax = plt.subplots()
        ax.bar(labels, values)  # Corrected line
        ax.set_title("Total Food Waste")
        ax.set_ylabel("Quantity")
        ax.set_xlabel("Food Type")
        st.pyplot(fig)
    if analysis=="Most claimed food items":  
        st.header("Most Claimed Food")
        query="""SELECT f.Food_Name, COUNT(*) AS ClaimCount
                FROM Foodlistings f
                JOIN claims c ON f.Food_ID = c.Food_ID
                GROUP BY Food_Name
                ORDER BY ClaimCount DESC
                """
        cursor.execute(query)
        result=cursor.fetchall()
        total_waste = result
        con.close()
        labels = [row[0] for row in result]
        values = [row[1] for row in result]
        df=pd.DataFrame(result,columns=["Name","Claim_Count"])
        styles = [
             
             {'selector': 'th', 'props': [('background-color', 'grey')]},
             {'selector': 'td', 'props': [('padding', '10px')]}]
        html_table=df.style.set_table_styles(styles).to_html()
        st.markdown(html_table, unsafe_allow_html=True)
        plt.title("Most claimed food items")
        fig, ax = plt.subplots()
        ax.bar(labels, values)  # Corrected line
        ax.set_title("Most Claimbed food")
        ax.set_ylabel("Name")
        ax.set_xlabel("Food Count")
        st.pyplot(fig)
      