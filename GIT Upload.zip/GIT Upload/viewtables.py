import streamlit as st
import pandas as pd
from  mysqlconn import get_connection

con=get_connection()
cursor=con.cursor()
st.title("Table Details")
def gettables():
    #st.title("Tables")
    Tables = st.selectbox("Select the table to view", ["Receivers", "Providers", "Claim","FoodListings"])

    if Tables=="Receivers":
        query="""
        SELECT * from Receivers;
            """
        cursor.execute(query)    
        result = cursor.fetchall()
        df=pd.DataFrame(result,columns=["Receiver_ID","Name","Type","City","Contact"])
        styles = [
             
             {'selector': 'th', 'props': [('background-color', 'grey')]},
             {'selector': 'td', 'props': [('padding', '10px')]}]
        html_table=df.style.set_table_styles(styles).to_html()
      
        st.markdown(html_table, unsafe_allow_html=True)
    elif Tables=="Providers":
        query='''
        SELECT * from Providers;
        '''
        cursor.execute(query)
        result=cursor.fetchall()
        df=pd.DataFrame(result,columns=["Provider_ID","Name","Type","Address","City","Contact"])
        styles = [
             
             {'selector': 'th', 'props': [('background-color', 'grey')]},
             {'selector': 'td', 'props': [('padding', '10px')]}]
        html_table=df.style.set_table_styles(styles).to_html()
        
        st.markdown(html_table, unsafe_allow_html=True)
       
    elif Tables=="Claim":
        query='''
        SELECT * from claims;
        '''
        cursor.execute(query)
        result=cursor.fetchall()
        df=pd.DataFrame(result,columns=["Claim_ID","Food_ID","Receiver_ID","Status","Timestamp"])
        styles = [
             
             {'selector': 'th', 'props': [('background-color', 'grey')]},
             {'selector': 'td', 'props': [('padding', '10px')]}]
        html_table=df.style.set_table_styles(styles).to_html()
        st.markdown(html_table, unsafe_allow_html=True)
        
    elif Tables=="FoodListings":
        query='''
        SELECT * from foodlistings;
        '''
        cursor.execute(query)
        result=cursor.fetchall()
        df=pd.DataFrame(result,columns=["Food_ID","Food_Name","Quantity","Expiry_Date","Provider_ID","Provider_Type","Location","Food_Type","Meal_Type"])
        styles = [
             
             {'selector': 'th', 'props': [('background-color', 'grey')]},
             {'selector': 'td', 'props': [('padding', '10px')]}]
        html_table=df.style.set_table_styles(styles).to_html()
        st.markdown(html_table, unsafe_allow_html=True)
    # else:
    #     st.write("No Tables")
       
