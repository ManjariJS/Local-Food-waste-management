import pandas as pd
import mysql.connector
from datetime import datetime

#upload the csv file

providers=pd.read_csv(r"C:\Users\vicky\OneDrive\Desktop\MiniProject\Source documents\providers_data.csv")
receivers=pd.read_csv(r'C:\Users\vicky\OneDrive\Desktop\MiniProject\Source documents\receivers_data.csv')
claims=pd.read_csv(r'C:\Users\vicky\OneDrive\Desktop\MiniProject\Source documents\claims_data.csv')
food_listings=pd.read_csv(r'C:\Users\vicky\OneDrive\Desktop\MiniProject\Source documents\food_listings_data.csv')

#database connection

conn=mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    autocommit=True,
    database='foodmanagementsystem'
)

cursor=conn.cursor()

#cursor.execute("use foodmanagementsystem")


cursor.execute("""CREATE TABLE IF NOT EXISTS PROVIDERS
               (Provider_ID INT auto_increment PRIMARY KEY,
                Name varchar(255),
                providers_type varchar(50),
               Address Text,
               City Varchar(100),
               Contact varchar(50) ) 
               
               """)
conn.commit()


for index,rows in providers.iterrows():
    cursor.execute(""" insert into providers(Provider_ID,Name,Type,Address,City,Contact) values (%s,%s,%s,%s,%s,%s)
                   """,tuple(rows))

conn.commit()
#print("insertion successful")

cursor.execute("""CREATE TABLE receivers(
                Receiver_id int primary key,
                Name varchar(100),
                Type varchar(100),
                City varchar(100),
                Contact varchar(100))""")


for index,rows in receivers.iterrows():
     cursor.execute(""" insert into receivers(Receiver_id,Name,type,City,Contact)values(%s,%s,%s,%s,%s)""",tuple(rows))

conn.commit()

# cursor.execute("""
#                 CREATE TABLE FOODLISTINGS 
#                 (
#                 FOOD_ID INT PRIMARY KEY,
#                FOOD_Name varchar(100),
#                 Quantity INT,
#                 Expiry_Date DATETIME,
#                 Provider_id INT,
#                 Provider_Type varchar(50),
#                 Location varchar(100),
#                 Food_Type Varchar(50),
#                 Meal_Type varchar(50),
#                 FOREIGN KEY (Provider_id) REFERENCES Providers(Provider_id),
#                 FOREIGN KEY (Provider_Type) REFERENCES Providers(providers_type))
               
#    """)

sql="insert into FOODLISTINGS(FOOD_ID,FOOD_Name,Quantity,Expiry_date,Provider_id,Provider_Type,Location,Food_Type,Meal_Type)values(%s,%s,%s,%s,%s,%s,%s,%s,%s)"
for index,rows in food_listings.iterrows():
     date_string=rows[3]
     print(date_string)
     datetime_object = datetime.strptime(date_string, '%m/%d/%Y')
     mysql_date = datetime_object.strftime('%Y-%m-%d')
     values=(rows[0],rows[1],rows[2],mysql_date,rows[4],rows[5],rows[6],rows[7],rows[8])
     cursor.execute(sql,values)

    #cursor.execute(""" insert into FOODLISTINGS(FOOD_ID,FOOD_Name,Quantity,Expiry_date,Provider_id,Provider_Type,Location,Food_Type,Meal_Type)values(%s,%s,%s,%s,%s,%s,%s,%s,%s)""",tuple(rows))
    


cursor.execute(""" CREATE TABLE claims (
              Claim_ID INT PRIMARY KEY,
               Food_ID INT,
              Receiver_ID INT,
               Status varchar(20),
               TIME_STAMP DATETIME,
               FOREIGN KEY (Food_ID) REFERENCES FOODLISTINGS(Food_ID),
               FOREIGN KEY (Receiver_ID) REFERENCES Receivers(Receiver_id))""" )


sql1="insert into claims(Claim_ID,Food_ID,Receiver_ID,STATUS,TIME_STAMP)values(%s,%s,%s,%s,%s)"
for index,rows in claims.iterrows():
    date_string=rows[4]
    print(date_string)
    datetime_object = datetime.strptime(date_string, '%m/%d/%Y %H:%M')
    mysql_date = datetime_object.strftime('%Y-%m-%d %H:%M')
    values1=(rows[0],rows[1],rows[2],rows[3],mysql_date)
    cursor.execute(sql1,values1)