import streamlit as st
import viewtables


    # st.title("Select a Purpose")
    # page=st.radio("Go to",["Receive","Provide","Claim","Check Availability","View Tables"])

# if page=="Home":
#     home.app()
#st.title("Tables")
viewtables.gettables()
st.markdown(
    """
    <style>
    .stApp {
        background-color: dark grey;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

    


# if page=="View Tables":
#     #Tables = st.selectbox("Select the table to view", ["Receivers", "Providers", "Claim","FoodListings"])




